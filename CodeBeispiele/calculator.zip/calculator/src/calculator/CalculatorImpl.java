package calculator;

public class CalculatorImpl implements Calculator {
    @Override
    public int plus(int a, int b) {
        return a+b;
    }
}
