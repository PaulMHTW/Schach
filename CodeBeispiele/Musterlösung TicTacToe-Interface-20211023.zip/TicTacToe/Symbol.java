public enum Symbol {
    KREIS,
    KREUZ;
}
