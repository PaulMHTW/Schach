public class FeldBelegtException extends Exception {
    public FeldBelegtException() { super(); }
    public FeldBelegtException(String message) { super(message); }
    public FeldBelegtException(String message, Throwable t) { super(message, t); }
}
