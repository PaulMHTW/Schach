public class SymbolBereitsBelegtException extends Exception {
    public SymbolBereitsBelegtException() { super(); }
    public SymbolBereitsBelegtException(String message) { super(message); }
    public SymbolBereitsBelegtException(String message, Throwable t) { super(message, t); }
}
