package chessgame.pieces;

public enum PieceColors {
    WHITE, BLACK
}
